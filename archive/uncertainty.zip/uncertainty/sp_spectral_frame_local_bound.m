function [bound, approx_bound, ktilde, itilde, dd] = sp_spectral_frame_local_bound(G,g,p,ii,k)

    bound = zeros(size(k));
    approx_bound = zeros(size(k));
    ktilde = zeros(size(k));
    itilde = zeros(size(k));
    dd = zeros(size(k));


    [A,B] = gsp_filterbank_bounds(G,g);
    Nf = numel(g);
    for jj = 1:numel(k)
        gi = gsp_localize(G,g{k(jj)},ii)/sqrt(G.N);

        Agg = gsp_filter_analysis(G,g,gi);

        [mA,k2] = max(abs(gsp_vec2mat(Agg,Nf)'));
        [~, itilde(jj)] = max(mA);
        ktilde(jj) = k2(itilde(jj));
        dd(jj) = gsp_hop_distanz(G,ii,itilde(jj));
        approx_bound(jj) = (B*G.N)^(1/p)/sqrt(A*G.N)*(norm(gi,2))^(abs(1-2/p));      
        gki = gsp_localize(G,g{ktilde(jj)},itilde(jj))/sqrt(G.N);
        bound(jj) = (B)^(1/p)/sqrt(A)*(norm(gki,2))^(abs(1-2/p)); 
    end
    
end
%
%   Url: https://epfl-lts2.github.io/rrp-html/uncertainty/sp_spectral_frame_local_bound.html

% Copyright (C) 2012-2013 Nathanael Perraudin.
% This file is part of RRP version 0.2
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.
end
