% Global and Local Uncertainty Principles for Signals on Graphs - Code
%
%   This package contains the code to reproduce all the figures of the
%   paper: 
%   
%   Global and Local Uncertainty Principles for Signals on Graphs
%
%   Authors: Nathanael Perraudin, Benjamin Ricaud, David I Shuman, Pierre
%   Vandergheynst 
%
%   ArXiv: http://arxiv.org/abs/1603.03030
%
%   Availlable experiments:
%    GLOBAL_ILLUSTRATION           -  Laplacian eigenvector localization
%    COMET_COHERENCE               -  Evolution of the coherence for the comet graph
%    MODIFIED_PATH_EIGENVECTORS    -  Display some eigenvectors for a modified path
%    MODIFIED_PATH_COHERENCE       -  Illustration on the modified path graph 
%    NORM_OF_LOCALIZATION_OPERATOR -  Illustration of the localization operator
%    SPREAD_GABOR                  -  Display the spread of different Gabor transforms
%    LOCAL_UNCERTAINTY             -  Local uncertainty illustration
%    ATOM_LOCALIZATION             -  Example of the localization of some atoms
%    MODIFIED_PATH_GABOR           -  Show global and local bounds on the modified path
%    ADAPTATED_SAMPLING            -  Adaptation of the sampling according to local uncertainy
%
%
%   Abstract of the paper
%   ---------------------
%
%   Uncertainty principles such as Heisenberg's provide limits on the
%   time-frequency concentration of a signal, and constitute an important
%   theoretical tool for designing and evaluating linear signal transforms.
%   Generalizations of such principles to the graph setting can inform
%   dictionary design for graph signals, lead to algorithms for
%   reconstructing missing information from graph signals via sparse
%   representations, and yield new graph analysis tools. While previous
%   work has focused on generalizing notions of spreads of a graph signal
%   in the vertex and graph spectral domains, our approach is to generalize
%   the methods of Lieb in order to develop uncertainty principles that
%   provide limits on the concentration of the analysis coefficients of any
%   graph signal under a dictionary transform whose atoms are jointly
%   localized in the vertex and graph spectral domains. One challenge we
%   highlight is that due to the inhomogeneity of the underlying graph data
%   domain, the local structure in a single small region of the graph can
%   drastically affect the uncertainty bounds for signals concentrated in
%   different regions of the graph, limiting the information provided by
%   global uncertainty principles. Accordingly, we suggest a new way to
%   incorporate a notion of locality, and develop local uncertainty
%   principles that bound the concentration of the analysis coefficients of
%   each atom of a localized graph spectral filter frame in terms of
%   quantities that depend on the local structure of the graph around the
%   center vertex of the given atom. Finally, we demonstrate how our
%   proposed local uncertainty measures can improve the random sampling of
%   graph signals.
%
%   References:
%     N. Perraudin, R. Benjamin, S. David I, and P. Vandergheynst. Global and
%     local uncertainty principles for signals on graphs. arXiv preprint
%     arXiv:1603.03030, 2016.
%     
%
%   Url: https://epfl-lts2.github.io/rrp-html/uncertainty/Contents.html

% Copyright (C) 2012-2013 Nathanael Perraudin.
% This file is part of RRP version 0.2
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.

% Undocumented code
%    UNCERTAINTY_BOUNDS            -  Compute the global uncertainty bound of some graphs

