function v=randsampleWRW(x,k,w)
% same than randsample but Without Replacement and with Weighting
%
%   Url: https://epfl-lts2.github.io/rrp-html/uncertainty/randsampleWRW.html

% Copyright (C) 2012-2013 Nathanael Perraudin.
% This file is part of RRP version 0.2
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.

% Returns V, a weigthed sample of K elements taken among X without replacement
% X a vector of numerics
% K amount of element to sample from x
% W a vector of positive weights w, whose length is length(x)

% EXAMPLE:
% for i=1:100
% v(i)=randsampleWRW([0,0.5,3,20],1,[0.5,0.4,0.05,0.05]);
% end
% plot(v,'o')

% Was initialy made by ROY, i just correct some details and add help
% see the link:
% http://www.mathworks.com/matlabcentral/newsreader/view_thread/141124
% Jean-Luc Dellis, april 2010

if k>length(x), error('k must be smaller than length(x)'), end
if ~isequal(length(x),length(w)),error('the weight W must have the length of X'),end
v=zeros(1,k);
for i=1:k
    v(i)=randsample(x,1,true,w);
    w(x==v(i))=0;
end
end
