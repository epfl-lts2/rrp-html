function [win_n] = ai_normalize_w(win,hop)
%AI_NORMALIZE_W Normalizes the window so that it yields a tight STFT
% 
%   Input parameters:
%       win         : input window
%       hop         : hop-size
%   Ouput parameters:
%       win_n       : normalized window
%
%
%
%   Url: https://epfl-lts2.github.io/rrp-html/audio_inpainting/ai_normalize_w.html

% Copyright (C) 2012-2013 Nathanael Perraudin.
% This file is part of RRP version 0.2
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.

% Authors: Nathanael Perraudin, Nicki Hollighaus
% Date   : June 2016

N = length(win);
K = floor(N/hop);
win_n = win.^2;
z = win_n;
for n = 1:K,%shift to the left
    z(1:end-n*hop) = z(1:end-n*hop) + win_n(n*hop+1:end);
end
for n = 1:K,%shift to the right
    z(n*hop+1:end) = z(n*hop+1:end) + win_n(1:end-n*hop);
end
win_n = win./sqrt(z);

end
