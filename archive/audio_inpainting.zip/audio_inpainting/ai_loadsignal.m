function [s,fs] =ai_loadsignal(filename,ratio)
%AI_LOADSIGNAL Load a signal, down-sample it, and make it mono
%   Usage:  [s, fs] =ai_loadsignal(filename)
%           [s, fs] =ai_loadsignal(filename, ratio)
%   
%   Input parameters:
%       filename    : name of the file (text)
%       ratio       : down-sampling ratio
%   Output parameters:
%       s           : signal
%       fs          : sampling frequency
%
%   This function load a signal, down-sample it and make it mono.
%
%
%   Url: https://epfl-lts2.github.io/rrp-html/audio_inpainting/ai_loadsignal.html

% Copyright (C) 2012-2013 Nathanael Perraudin.
% This file is part of RRP version 0.2
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.


if nargin<2
    ratio = 1;
end

% read the file
try
    [s,fs] = audioread(filename);
catch
    [s,fs] = audioread2(filename);
end

if size(s,2) >=1
    s = mean(s,2);
end
fs = fs/ratio;
s = resample(s,1,ratio);
end
