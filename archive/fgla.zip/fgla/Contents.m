%   A fast Griffin lim algorithm
%
%   AN EXTENDED GRIFFIN LIM ALGORTITHM
%
%   Paper: Perraudin Nathanael, Balazs Peter
%   
%   Demonstration matlab file:  Perraudin Nathanael
%
%   In this paper, we present a new algorithm to estimate a signal from its
%   short-time Fourier transform modulus (STFTM). This algorithm is
%   computationally simple and is obtained by an acceleration of the
%   well-known Griffin-Lim algorithm (GLA). Before deriving the algorithm,
%   we will give a new interpretation of the GLA and formulate the phase
%   recovery problem in an optimization form. We then present some
%   experimental results where the new algorithm is tested on various
%   signals. It shows not only significant improvement in speed of
%   convergence but it does as well recover the signals with a smaller
%   error than the traditional GLA.
%
%   Conference paper:
%   https://lts2research.epfl.ch/unlocbox/notes/unlocbox-note-007.pdf
%
%   Cite this paper
%   https://lts2research.epfl.ch/unlocbox/notes/unlocbox-note-007.bib
%
%  Availlable experiments
%    RR_ALPHA - Test the influence of the parameter alpha
%    RR_SIGNALS - Phase reconstruction experiments on different signals
%    RR_SPECTRO_MULT - Spectrogram multiplication experiment on different signals
%
%  For help, bug reports, suggestions etc. please send email to
%  nathanael (dot) perraudin (at) epfl (dot) ch
%
%
%   Url: https://epfl-lts2.github.io/rrp-html/fgla/Contents.html

% Copyright (C) 2012-2013 Nathanael Perraudin.
% This file is part of RRP version 0.2
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.

