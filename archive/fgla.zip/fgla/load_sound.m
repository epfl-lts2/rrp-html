function [ s,fs ] = load_sound( name )
%LOAD_SOUND Load one of the following sound: 
%   Usage: s = load_sound( name );
%          [ s,fs ] = load_sound( name );
%
%   Input parameters:
%         name  : Name of the sound.
%   
%   Output parameters:
%         s     : signal.
%         fs    : sampling frequency.
%
%   This function load a sound from the LTFAT toolbox by is name. The name
%   availlable are:
%
%    bat
%    cocktailparty
%    greasy
%    gspi
%    linus
%    otoclick
%    traindoppler
%
%   In order to speed up computation it return only "power of 2" numbers of
%   samples.
%
%
%   Url: https://epfl-lts2.github.io/rrp-html/fgla/load_sound.html

% Copyright (C) 2012-2013 Nathanael Perraudin.
% This file is part of RRP version 0.2
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.

% Load the sound
if strcmp(name,'bat')
   [s,fs]= bat();
elseif strcmp(name,'cocktailparty')
   [s,fs]= cocktailparty();
elseif strcmp(name,'greasy')
   [s,fs]= greasy();
elseif strcmp(name,'gspi')
   [s,fs]= gspi();
elseif strcmp(name,'linus')
   [s,fs]= linus();
elseif strcmp(name,'otoclick')
   [s,fs]= otoclick();
elseif strcmp(name,'traindoppler')
   [s,fs]= traindoppler();
else
   error('Incorrect sound name!'); 
end



% Cut the extra part of th sound. We work with "power of 2" number of
% samples.
%length(s);
%N=floor(log(length(s))/log(2));
%s=s(1:2^N);

end


