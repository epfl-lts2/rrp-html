function plot_ambiguity(g,dr)

z = 2.5;

L = length(g);
g = fir2long(g,ceil(z*L));
L = length(g);
G = abs(dgt(g,g,1,L));
G = G/max(G(:));
% norm(G(:),1);
%
%   Url: https://epfl-lts2.github.io/rrp-html/gdwuco/undocumented/plot_ambiguity.html

% Copyright (C) 2012-2013 Nathanael Perraudin.
% This file is part of RRP version 0.2
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.
G =20*log10(G);
%mG = max(G(:));

x=linspace(-z*L/2,z*L/2,z*L);
y=linspace(-z/2,z/2,z*L);

imagesc(x,y,fftshift(G),[-dr,0]);

colorbar;

%axis off;

end

