% Produce all plots for the article
%
%   Url: https://epfl-lts2.github.io/rrp-html/gdwuco/undocumented/produce_plots.html

% Copyright (C) 2012-2013 Nathanael Perraudin.
% This file is part of RRP version 0.2
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.

global GLOBAL_save
global GLOBAL_baw
global GLOBAL_figpaper

GLOBAL_baw = 0;         % to save the result in black and white
GLOBAL_save = 1;        % or 1 if you want to save the figures
GLOBAL_figpaper= 1;     % to make the figure for the paper 

rr_introduction;
rr_beat_itersine;
rr_gabfirdual_smoothness;
rr_gabfirtight;
rr_gaboptdual;
rr_tradeoff_smoothness;
rr_gabfirdual

%%
GLOBAL_figpaper= 0;     % to make the figure for the paper 

rr_gabfirtight;
rr_beat_itersine;

