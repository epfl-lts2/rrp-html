function [gd,Gcut]=gabfirdual_pinv(Ldual,g,a,M)

% Determine the window. The window /must/ be an FIR window, so it is
% perfectly legal to specify L=[] when calling gabwin
%
%   Url: https://epfl-lts2.github.io/rrp-html/gdwuco/undocumented/gabfirdual_pinv.html

% Copyright (C) 2012-2013 Nathanael Perraudin.
% This file is part of RRP version 0.2
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.
[g,info]=gabwin(g,a,M,[]);

% Determine L. L must be longer than L+Ldual+1 to make sure that no convolutions are periodic
L=dgtlength(info.gl+Ldual+1,a,M);
b=L/M;



% Determine an L that is so large that the system is underdetermined,
% even when reducing the number of variables
% Ldual must be less than a*b
% => b must be larger than ceil(Ldual/a)

Lfirst=ceil(Ldual/2);
Llast=Ldual-Lfirst;
glong=fir2long(g,L);

F=frame('dgt',glong,M,a);
G=frsynmatrix(F,L);




Gcut=G([1:Lfirst,L-Llast+1:L],:);
%size(Gcut)
gd=pinv(Gcut.')*[a/M;zeros(a*b-1,1)];

