function X = pinvs(A,varargin)
%PINVS   Pseudoinverse for symetric matrices.
%   X = PINVS(A) compute the pseudo inverse of a symetric matrix
%
%
%   Url: https://epfl-lts2.github.io/rrp-html/gdwuco/undocumented/pinvs.html

% Copyright (C) 2012-2013 Nathanael Perraudin.
% This file is part of RRP version 0.2
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.


if isempty(A)     % quick return
  X = zeros(size(A'),class(A));  
  return  
end

% Be sure that the matrix is symetric
A = (A +A')/2;

n = size(A,1);


[Q,S] = eig(A);

Q = fliplr(Q);
   
s = flipud(real(diag(S)));

if nargin == 2
  tol = varargin{1};
else
  tol = n * eps(max(s));
end
r = sum(s > tol);
if (r == 0)
  X = zeros(size(A),class(A));
else
  s = diag(ones(r,1)./s(1:r));
  X = Q(:,1:r)*s*Q(:,1:r)';
end

end

