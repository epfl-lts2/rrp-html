function [ g ] = aritight( a,M )
%ARITIGHT Create the aritight windows for parameters a and M
%
%   Url: https://epfl-lts2.github.io/rrp-html/gdwuco/undocumented/aritight.html

% Copyright (C) 2012-2013 Nathanael Perraudin.
% This file is part of RRP version 0.2
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.


Lg=M;
Ldual=M;

% For testing the reconstruction
Llong=dgtlength(10*(Ldual+Lg),a,M);


% Initial windows
g=firwin('itersine',Lg);


%parameter for convex optimization
    mu=0;         % smoothing parameter in time
    gamma=0;      % smoothing parameter in frequency
    delta=0.1/sqrt(2*M);  % parameter for the Gabor transform



maxit=500;   % maximum number of iteration
tol=1e-7;    % tolerance to stop iterating


fprintf('Compute the window \n');
% call optimization routine
gd=gabfirdual(Ldual,g,a,M,'mu',mu,...
    'gamma',gamma,'maxit',maxit,'tol',tol,'delta',delta);




%%
g=real(fir2long(gabtight(gd,a,M),Ldual));

if gabdualnorm(g,g,a,M,Llong)>10e-14
fprintf('  Reconstruction error of the tight window: %g \n',...
                                gabdualnorm(g,g,a,M,Llong));
end


end


