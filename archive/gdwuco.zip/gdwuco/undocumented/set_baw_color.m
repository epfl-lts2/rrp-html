function [ ] = set_baw_color(  )
%SET_BAW_COLOR Set all color to black and white
%
%   Url: https://epfl-lts2.github.io/rrp-html/gdwuco/undocumented/set_baw_color.html

% Copyright (C) 2012-2013 Nathanael Perraudin.
% This file is part of RRP version 0.2
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.
    
% for imagesc
colormap(flipud(gray))
% for plot
hline = findobj(gcf, 'type', 'line');
set(hline,'LineWidth',1.5)
    % add other symbol if more than one plot
    for ii=1:length(hline)
        switch mod(ii,4)
            case 1
                set(hline(ii),'LineStyle','-') 
                set(hline(ii),'color','k');
            case 2
                set(hline(ii),'LineStyle',':') 
                set(hline(ii),'color','k');
            case 3
                set(hline(ii),'LineStyle','-') 
                set(hline(ii),'color',[0.5 0.5 0.5]);

            case 0
                set(hline(ii),'LineStyle','-') 
                set(hline(ii),'color',[0.75 0.75 0.75]);
        end
    end

end


