function [ s ] = plot_window_proj( x,p,fig,proj,filename )
%PLOT_WINDOW Plot image plugin for the UNLocBoX
%   Usage [ s ] = plot_window_proj( x,p,fig,proj,filename);
%             s = plot_window_proj( x,p,fig,proj);
%
%   Input parameters:
%         x     : Structure of data
%         p     : Number of iteration between 2 plots...
%         fig   : Figure
%         proj  : projection
%         filename  : filename for the gif
%
%   Output parameters:
%         s     : Input image
%
%   This plugin display the window every iterations of an algorithm. To use
%   the plugin juste define:
%       
%       fig=figure(100);
%       param.do_sol=@(x) plot_window(s,p,fig,proj);
%
%   In the structure of optional argument of the solver.
%
%
%   Url: https://epfl-lts2.github.io/rrp-html/gdwuco/undocumented/plot_window_proj.html

% Copyright (C) 2012-2013 Nathanael Perraudin.
% This file is part of RRP version 0.2
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.

% Author: Nathanael Perraudin
% Date  : 3rd april 2014

if ~mod(x.iter-1,p)
    % select the figure
    if x.iter<2
        figure(fig);
    end
    % display the signal
    g = real(x.sol);
    Lg = length(g);


    if mod(Lg,2)
        a =-(Lg-1)/2:(Lg-1)/2;
    else
        a = -Lg/2:(Lg/2-1);
    end

    plot(a,real(fftshift(proj(g))));
        xlim([min(a),max(a)]);

    title(['Current it: ', num2str(x.iter),'   Curr obj: ', ...
        num2str(x.curr_norm)]);

    drawnow;
end

% return the signal
s=x.sol;

if filename
      frame = getframe(fig);
      im = frame2im(frame);
      [imind,cm] = rgb2ind(im,256);  
      dt = 0.1;
    if x.iter == 2;
        imwrite(imind,cm,[filename,'.gif'],'gif','DelayTime',dt,...
             'Loopcount',inf,'writemode','overwrite');
    else
    	imwrite(imind,cm,[filename,'.gif'],'gif','DelayTime',dt,...
            'WriteMode','append');
    end
end


end


