function gd=gabfirdual_cvx(Ldual,g,a,M,alpha1,alpha2,mu,gamma)


%length
%
%   Url: https://epfl-lts2.github.io/rrp-html/gdwuco/undocumented/gabfirdual_cvx.html

% Copyright (C) 2012-2013 Nathanael Perraudin.
% This file is part of RRP version 0.2
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.
Lg=length(g);
L=dgtlength(Lg+Ldual+1,a,M);
b=L/M;

%initial point
    gsmall=long2fir(g,M);
    gdsmall=gabdual(gsmall,a,M);

%Projection
    glong=fir2long(g,L);
    G=tfmat('dgt',glong,M,a);
    d=[a/M;zeros(a*b-1,1)];
    
% Constraint
    Lz=Ldual/2;
    ind=Lz:L-Lz;

% Matrix
    F=tfmat('fourier',L) ;
    Grad=eye(L)-circshift(eye(L),[0,-1]);
    
    

cvx_begin
    variable X(L)
    cvx_precision best
    minimize( alpha1*norm(X,1) +alpha2 *norm(F*X,1) + mu* norm(Grad*X,2) + gamma * norm(Grad*F*X,2))
    subject to
        G'*X == d
        X(ind) == 0
cvx_end


gd=long2fir(X,Ldual);
end

    

