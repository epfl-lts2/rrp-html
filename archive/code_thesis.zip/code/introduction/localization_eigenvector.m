% eigenvector localization
gsp_reset_seed(1);

N = 100;
G = gsp_sensor(N);

G = gsp_compute_fourier_basis(G);


figure(1)
c = [-0.2 0.2];
subplot(221)
gsp_plot_signal(G,G.U(:,2))
title('Eigenvector no $1$');
caxis(c);
subplot(222)
gsp_plot_signal(G,G.U(:,3))
title('Eigenvector no $2$');
caxis(c);

subplot(223)
gsp_plot_signal(G,G.U(:,50))
title('Eigenvector no $49$');
caxis(c);

subplot(224)
gsp_plot_signal(G,G.U(:,51))
title('Eigenvector no $50$');
caxis(c);

thesis_resize(gcf,0.6)
thesis_printfig(gcf,'intro_eigenvector_localization')
