
clear all;
close all;

global extvar;
global M;
global normalized;
global name;
global type;


extvar = 1;
M = 30;
normalized = 0;

type = 'scaleogram';
name = 'community'; 
demo_graph_spectrogram

type = 'spectrogram'; 
name = 'tree'; 
demo_graph_spectrogram
name = 'comet';
demo_graph_spectrogram
name = 'sensor';
demo_graph_spectrogram
name = 'community'; 
demo_graph_spectrogram