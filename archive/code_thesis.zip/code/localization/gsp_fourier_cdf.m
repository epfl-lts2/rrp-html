function v = gsp_fourier_cdf(G,x)

v = zeros(G.N,numel(x));
for ii=1:numel(x)
    v(:,ii) = sum(abs(G.U(:,G.e<=x(ii))).^2,2);
end

end