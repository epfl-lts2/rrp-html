function dist = get_emd_distance(M)


D = zeros(M);
for ii = 0:(M-1)
    D(ii+1,:) = circshift(0:(M-1),[0,ii]);
end

    dist = @(x,y) emd_loop(x,y,D);
    
end

function d = emd_loop(x,y,D)
d = zeros(size(x,1),size(y,1));
for ii = 1:size(x,1)
    for jj = 1:size(y,1)
        d(ii,jj) = emd_hat_gd_metric_mex(x(ii,:)',y(jj,:)',D); 
    end
end

end