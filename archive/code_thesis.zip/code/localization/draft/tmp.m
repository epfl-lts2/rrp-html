
%%
N = 100000;
d= 3;
v = rand(d,1);
v = v/norm(v);
% v = zeros(d,1);
% v(1)=1;
%v = ones(d,1);
x = sign(randn(d,N));

XX2 = zeros(d,d,d,d);
dd2 = 0;
for ii = 1:d
   for jj = 1:d
      for kk = 1:d
         for ll = 1:d
             XX2(ii,jj,kk,ll) = sum(x(ii,:).*x(jj,:).*x(kk,:).*x(ll,:))/N;
             dd2 = dd2+ sum(v(ii)*v(jj)*v(kk)*v(ll)*x(ii,:).*x(jj,:).*x(kk,:).*x(ll,:))/N;
         end       
      end
   end
   
end
figure(2)
imagesc(reshape(XX2,d*d,d*d));
% s = sum(XX2(:))-d
% 
% dd2-norm(v,2)^4
a = (mean(x(:).^4)-3)*norm(v,4)^4 + 3*norm(v,2)^4-norm(v,2)^4
b = var((v'*x).^2)


%%


