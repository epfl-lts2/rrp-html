function m = gsp_filter_mass_center(G,g)

x = linspace(-G.lmax/2,3/2*G.lmax,1000)';
fx = abs(gsp_filter_evaluate(g,x));

x = repmat(x,1,size(fx,2));

m = sum(x .* fx)./sum(fx);


end