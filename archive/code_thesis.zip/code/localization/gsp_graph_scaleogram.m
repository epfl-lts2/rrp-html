function [ SC,h] = gsp_graph_scaleogram( G,g,a,param )


if nargin<4
    param = struct;
end

if ~isfield(param,'rand_sig_number'), param.rand_sig_number = 100; end
if ~isfield(param,'exact'), param.exact = 0; end
if ~isfield(param,'paramfilter'), param.paramfilter = struct; end



h = cell(numel(a),1);
for ii = 1:numel(a)
    h{ii} = @(x) g(a(ii)*x)/sqrt(a(ii));
end


SC = gsp_norm_tig(G,h,param.exact,param.rand_sig_number,param.paramfilter);


end

