function  err = rel_norm(exact,approx)

    err = norm(exact-approx,'fro')/norm(exact,'fro');


end

