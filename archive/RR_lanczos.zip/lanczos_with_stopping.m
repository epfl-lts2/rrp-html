function [V,H,prev,error,error2,k] = lanczos_with_stopping(G,order,x,func,d,tol)

param.method = 'exact';
exact = gsp_filter_analysis(G, func, x, param);
A = G.L;

N = length(x);
Nf = numel(func);
% normalization
norm_x = norm(x,2);
q = x/norm_x;

H = zeros(order+1,order);
V(:,1) = q;
 

r = A*q;
H(1,1) = q'*r;
r = r - H(1,1)*q ; 
H(2,1) = norm(r);


error = [];
error2 = [];

prev = zeros(N*Nf,1);
new = prev;

   for ii = 1:Nf
    % prev((1:N) + N*(ii-1),jj) =q(:,jj)*func{ii}(H(1,(jj-1)*order + 1))*q(:,jj)'*x(:,jj);
      prev((1:N) + N*(ii-1),:) = q*func{ii}(H(1,1))*norm_x;
   end

ind = 0;

  
 for k = 2:order 
    
    if (abs(H(k,k-1)) <= 1e-15)
        H = H(1:k-1,1:k-1);
        return;
    end
    
    H(k-1,k) = H(k,k-1);
    v = q;
    q = r/H(k-1,k);
    V(:,k) = q;
  
    r = A*q;
    r = r - H(k-1,k)*v;
    H(k,k) = q'*r;
    
    r = r - H(k,k)*q;
    r = r - V*(V'*r); 
    H(k+1,k) = norm(r);
         
    
        if (mod(k, d) == 0)
    
           ind = ind+1; 
           [Uh, Eh] = eig(H(1:k,1:k));
           Eh = diag(Eh);
           Eh(Eh<0) = 0;
           fie = gsp_filter_evaluate(func,Eh);

           for ii=1:Nf        
              new((1:N) + N*(ii-1),:) = (V*Uh)*(fie(:, ii).*((V*Uh)'*x));
           end
           
           %delta = rel_norm(new, prev); 
           delta = norm(new - prev);
           error = [error, delta];
           error2 = [error2, norm(exact - new)];
          
           if (delta < tol)
             prev = new; 
             return;
           end
           
           prev = new;
       end
     
 end
 
end