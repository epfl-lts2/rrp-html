%LANCZOS_EXPERIMENT2 Compare chebyshef VS lanczos for various graphs 
%
%   Paper: Accelerated filtering on graphs using Lanczos method
%
%   Authors: Ana Susnjara, Nathanael Perraudin, Daniel Kressner, and Pierre
%   Vandergheynst 
%
%   Dependecies: In order to run this script you need the GSPBOX. You can
%   download it at: https://lts2.epfl.ch/gsp/
%
%   About this experiment
%   ---------------------
%   
%   The purpose of this example is to investigate how the approximation by
%   the Chebyshev polynomial method and the Lanczos method depends on the
%   edge sparsity of the Erd{\H o}s ? R{\'e}nyi graph. We consider graphs
%   with $N = 1000$ nodes. The order of Chebyshev polynomial and Lanczos
%   method are set to $M = 30$. As a filterbank, we the use mexican hat
%   wavelet, with a mother window      
%   
%   math:: g_h(\lambda_\ell) =  \lambda_\ell \cdot \operatorname{exp}(-\lambda_\ell^2)\text{,}
%   
%   with $\lambda_\ell$ eigenvalues of graph Laplacian. In order to obtain
%   a complete filterbank, we add a low pass filter $g_l(\lambda_\ell) =
%   \operatorname{exp}(-\lambda_\ell^4)$.    
%
%   We notice that the Lanczos method exhibits excellent numerical
%   behaviour in comparison with the Chebyshev method, particularly when
%   using non-adapted filters. As the probability $p$ increases, the
%   (relative) spectral gap increases as well, leading to more accurate
%   Lanczos approximation.      
%
%   References: shuman2013spectrum perraudin2014gspbox ana2015accelerated

%% Initialization
clear;
close all;
clc;

%% Parameters

N = 1000;        % Size of the graph

p = (1:5:100)/N; % probabilites
order = 30;
Nf = 10;        % number of filters



%%
err_cheby = zeros(length(p),1);
err_lanczos = zeros(length(p),1);
err_cheby2 = zeros(length(p),1);
err_lanczos2 = zeros(length(p),1);

paramplot.eps = 1;

parfor ii=1:length(p)
    param = struct;
    % Select the graph
%   G = gsp_comet(N,Nstar(ii));
    
    G = gsp_erdos_renyi(N,p(ii));
    G = gsp_compute_fourier_basis(G);

    % Create the filterbank

    g = gsp_design_mexican_hat(G,Nf);
    G = gsp_spectrum_cdf_approx(G);
    paramwt = struct;
    paramwt.filter = g;
    paramwt.log = 1;
    g2 = gsp_design_warped_translates(G, Nf,paramwt);

    param.method = 'exact';
    
    s = rand(N,5);
    
    sol = gsp_filter_analysis(G,g,s,param);
    sol2 = gsp_filter_analysis(G,g2,s,param);

    param.order = order;
    
    param.method = 'cheby';
    cheb_approx = gsp_filter_analysis(G,g,s,param);  
    err_cheby(ii) = norm(sol-cheb_approx);    
    cheb_approx = gsp_filter_analysis(G,g2,s,param);  
    err_cheby2(ii) = norm(sol2-cheb_approx);

    param.method = 'lanczos';
    lanczos_approx = gsp_filter_analysis(G,g,s,param);  
    err_lanczos(ii) = norm(sol-lanczos_approx);    
    lanczos_approx = gsp_filter_analysis(G,g2,s,param);  
    err_lanczos2(ii) = norm(sol2-lanczos_approx);

    
end

%% Display the solution

figure(1)
semilogy(p,err_lanczos,'r', p,err_cheby, 'b', 'Linewidth', 1.2);
legend('Lanczos','Chebyshev')
xlabel('p')
ylabel('error')
%title('Non adaptated filters - Order 30')
paramplot.position = [100 100 300 220];
gsp_plotfig('erdos_order30_non_adapted',paramplot);

figure(2)
semilogy(p,err_lanczos2, 'r', p,err_cheby2, 'b', 'Linewidth', 1.2);
legend('Lanczos','Chebyshev')
xlabel('p')
ylabel('error')
%title('Adaptated filters  - Order 30')
paramplot.position = [100 100 300 220];
gsp_plotfig('erdos_order30_adapted',paramplot);

%%

G = gsp_erdos_renyi(N,p(end));
G = gsp_compute_fourier_basis(G);

% Create the filterbank

g = gsp_design_mexican_hat(G,Nf);
G = gsp_spectrum_cdf_approx(G);
paramwt = struct;
paramwt.filter = g;
paramwt.log = 1;
g2 = gsp_design_warped_translates(G, Nf,paramwt);

figure(3)
parampf.show_sum = 0;
gsp_plot_filter(G,g,parampf)
%title('Mexican Hat - Non adapted filters')
gsp_plotfig('erdos_non_adapted',paramplot);

figure(4)
gsp_plot_filter(G,g2,parampf)
%title('Mexican Hat - Adapted filters')
gsp_plotfig('erdos_adapted',paramplot);

