%LANCZOS_EXPERIMENT1 Compare chebyshef VS lanczos for various graphs 
%
%   Paper: Accelerated filtering on graphs using Lanczos method
%
%   Authors: Ana Susnjara, Nathanael Perraudin, Daniel Kressner, and Pierre
%   Vandergheynst 
%
%   Dependecies: In order to run this script you need the GSPBOX. You can
%   download it at: https://lts2.epfl.ch/gsp/
%
%   About this experiment
%   ---------------------
%   
%   We consider the sensor graph and the Erdos ? Renyi random graph, with
%   $N = 500$ nodes. In the latter case, each edge is included in the graph
%   with probability $p = 0.04$. As a filterbank, we use a collection of
%   translated windows $g(t) = \sin(0.5\pi\cos(\pi t)^2)\chi_{[-1/2,1/2]}$,
%   where $\chi_{I}$ is the characteristic function of $I$.     
%
%   This construction forms a tight frame in case of half overlap, i.e.
%   translation by steps of $1/2$. This tightness property is equivalent to
%   asserting that the sum of the squared modulus of the translated windows
%   is a constant, a property that is retained for any appropriately
%   sampled version.
%
%   We choose to adapt the filterbank to the graph spectrum, since
%   non-adapted filters lead to very coherent frames for graphs with
%   eigenvalues not uniformly spread along the spectrum.   
%   
%   In this example, we set $j = 3$ and $\epsilon = 10^{-3}$. The figure shows
%   that the estimate is sharp and thus can be used as a stopping criterion
%   in Lanczos algorithm.
%
%   In the firgues we observe that the Lanczos method yields better
%   approximation, especially in the case when the spectrum of graph
%   Laplacian is not uniformly distributed and has a large (relative)
%   spectral gap.
%
%   References: shuman2013spectrum perraudin2014gspbox ana2015accelerated


%% Initialization
clear;
close all;
clc;

gsp_reset_seed(0);

paramplot.position = [100 100 300 200];
paramplot.eps = 1;
%% Parameters

N = 500;        % Size of the graph

order = 5:5:100; % Maximum order

Nf = 10;        % number of filters

%% Select the graph

p = 20/N;
G1 = gsp_sensor(N);
G2 = gsp_erdos_renyi(N,p);

G1 = gsp_compute_fourier_basis(G1);
G2 = gsp_compute_fourier_basis(G2);

%% Create a filterbank

g1 = gsp_design_itersine(G1, Nf); 
g2 = gsp_design_itersine(G2, Nf); 

G1 = gsp_spectrum_cdf_approx(G1);
paramwt.filter = g1;
g1 = gsp_design_warped_translates(G1, Nf,paramwt);

G2 = gsp_spectrum_cdf_approx(G2);
paramwt.filter = g2;
g2 = gsp_design_warped_translates(G2, Nf,paramwt);

param.method = 'exact';

%%
s1 = sign(G2.U(:,2))/2;
sol1 = gsp_filter_analysis(G1,g1,s1,param);
s2 = sign(G2.U(:,2));
sol2 = gsp_filter_analysis(G2,g2,s2,param);

%%
err_cheby1 = zeros(length(order),1);
err_lanczos1 = zeros(length(order),1);
err_cheby2 = zeros(length(order),1);
err_lanczos2 = zeros(length(order),1);

time_lanczos1 = zeros(length(order),1);
time_lanczos2 = zeros(length(order),1);
time_cheby1 = zeros(length(order),1);
time_cheby2 = zeros(length(order),1);

for ii=1:length(order)
    param = struct;
    param.order = order(ii);
    
    param.method = 'cheby';
    t1 = tic;
    cheb_approx = gsp_filter_analysis(G1,g1,s1,param);  
    time_cheby1(ii) = toc(t1);
    err_cheby1(ii) = norm(sol1-cheb_approx);
    t2 = tic;
    cheb_approx = gsp_filter_analysis(G2,g2,s2,param);
    time_cheby2(ii) = toc(t2);

    err_cheby2(ii) = norm(sol2-cheb_approx);

    param.method = 'lanczos';
    t3 = tic;
    lanczos_approx = gsp_filter_analysis(G1,g1,s1,param);  
    err_lanczos1(ii) = norm(sol1-lanczos_approx);
    time_lanczos1(ii) = toc(t3);
    t4 = tic;
    lanczos_approx = gsp_filter_analysis(G2,g2,s2,param);
    err_lanczos2(ii) = norm(sol2-lanczos_approx);
    time_lanczos2(ii) = toc(t4);

end

%%
  d = 3; 
  tol = 1e-3;
  ord1 = 200;
  ord2 = 200;
 s1 = rand(N,1);
 s2 = s1;
  [V,H,prev,err_11,err_12, it1] = lanczos_with_stopping(G1,ord1,s1,g1,d,tol); 
 [V,H,prev,err_21,err_22, it2] = lanczos_with_stopping(G2,ord2,s2,g2,d,tol); 
 
 %%
close all
  ind1 = d:d:it1;
  ind2 = d:d:it2;
  
 figure(1)
 semilogy(ind1, err_11, 'b', ind1, err_12, 'r', 'Linewidth', 1.2)
 legend('error estimate','error')
 xlabel('order')
 %title('Sensor-stopping criteria')
 gsp_plotfig('sensor_iter_error',paramplot)
 
 figure(2)
 semilogy(ind2, err_21, 'b', ind2, err_22, 'r', 'Linewidth', 1.2)
 legend('error estimate','error')
 xlabel('order')
 %title('Erdos-stopping criteria')
 gsp_plotfig('erdos_iter_error',paramplot)
 
 
%% Plot the accuracy curves

figure(3)
semilogy(order,err_lanczos1, 'r', order,err_cheby1,'b', 'Linewidth', 1.2);
legend('Lanczos','Chebyshev')
xlabel('order')
ylabel('error')
%title('Sensor')
gsp_plotfig('Sensor',paramplot)

figure(4)
semilogy(order,err_lanczos2,'r', order,err_cheby2,'b','Linewidth', 1.2);
legend('Lanczos','Chebyshev')
xlabel('order')
ylabel('error')
%title('Erdos renyi, p = 20/N')
gsp_plotfig('Erdos_Renyi',paramplot)
%%
% figure(5)
% semilogy(order,time_lanczos1,'r', order,time_cheby1,'b', 'Linewidth', 1.2)
% legend('Lanczos','Chebyshev')
% xlabel('order')
% ylabel('CPU time')
% title('Sensor graph - mexican hat filterbank')
% 
% figure(6)
% semilogy(order,time_lanczos2, 'r', order,time_cheby2, 'b', 'Linewidth', 1.2);
% legend('Lanczos','Chebyshev')
% xlabel('order')
% ylabel('CPU time')
% title('Erdos renyi graph p = 10/N - mexican hat filterbank')

%% Plot the sensor graph
figure(7)
G1.plotting.edge_color = [0.5 0.5 0.5];
gsp_plot_signal(G1,G1.U(:,2))
%title('Sensor graph - Fiedler vector')
paramplot2 = paramplot;
paramplot2.position = [100 100 600 400];
gsp_plotfig('sensor_graph',paramplot2);

%% Plot the histogram of the eigenvalues

figure(8)
hist(G1.e,20);
axis tight
%title('Sensor - Hist. of eig.')
gsp_plotfig('hist_sensor',paramplot);

figure(9)
hist(G2.e,20);
axis tight
%title('Erdos Renyi - Hist. of eig.');
gsp_plotfig('hist_erdos',paramplot)
%%
figure(10);
paramplot.show_sum = 0;
gsp_plot_filter(G1,g1,paramplot);
%title('Sensor - Adapted filterbank');
gsp_plotfig('filter_sensor',paramplot)


figure(11);
paramplot.show_sum = 0;
gsp_plot_filter(G2,g2,paramplot);
%title('Erdos Renyi - Adapted filterbank');
gsp_plotfig('filter_erdos',paramplot)
