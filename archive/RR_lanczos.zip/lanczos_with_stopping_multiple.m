function [V,H,prev,error, error2, flag,k] = lanczos_with_stopping_multiple(G,order,x,func,d,tol)

param.method = 'exact';
exact = gsp_filter_analysis(G, func, x, param);

A = G.L;

[N,M] = size(x);
Nf = numel(func);
% normalization

for i = 1:M 
    normx = norm(x(:,i));
    q(:,i) = x(:,i)/normx;
end

H = [];
V = [];

for i = 1:M 
    H{i} = zeros(order + 1, order);
    V{i}(:, 1) = q(:, i);
end
r = A*q;

for i = 1:M
  %r(:,i) = A*q(:,i);
  H{i}(1,1) = q(:, i)'*r(:,i);
  r(:,i) = r(:, i) - H{i}(1,1)*q(:,i) ; 
  H{i}(2,1) = norm(r(:,i));  
end

 prev = zeros(N*Nf,M);
 new = prev;
 flag = zeros(M,1);
 error = prev;
 error2 = error;
 
 for jj = 1:M
   for ii = 1:Nf
    % prev((1:N) + N*(ii-1),jj) =q(:,jj)*func{ii}(H(1,(jj-1)*order + 1))*q(:,jj)'*x(:,jj);
      prev((1:N) + N*(ii-1),jj) = q(:,jj)*func{ii}(H{i}(1,1))*norm(x(:,jj));
   end
 end

 it = 0;

 for k = 2:order

       v = q;
  for i = 1:M
      if (flag(i) == 0)
       H{i}(k-1,k) = H{i}(k,k-1);
      
       q(:,i)= r(:,i)/H{i}(k-1,k);
       V{i}(:,k) = q(:,i);
       r(:,i) = A*q(:,i);

       r(:,i) = r(:,i) - H{i}(k-1,k)*v(:,i);
       H{i}(k,k) = q(:,i)'*r(:,i);
    
       r(:,i) = r(:,i) - H{i}(k,k)*q(:,i);
       r(:,i) = r(:,i) - V{i}*(V{i}'*r(:,i)); 
       H{i}(k+1,k) = norm(r(:,i));
      end 
      
  end     
    
     if (mod(k, d) == 0)
    
          it = it+1;
          
          for i = 1:M
            if (flag(i) == 0)   
              [Uh, Eh] = eig(H{i}(1:k,1:k));
              Eh = diag(Eh);
              Eh(Eh<0) = 0;
              fie = gsp_filter_evaluate(func,Eh);

              for ii=1:Nf        
                 new((1:N) + N*(ii-1),i) = (V{i}*Uh)*(fie(:, ii).*((V{i}*Uh)'*x(:,i)));
              end
              
              delta = norm(prev(:,i) - new(:,i))/norm(new(:,i));
              error(it,i) = abs(delta/(1-delta))*norm(new(:,i));
              error2(it,i) = norm(new(:,i) - exact(:,i));
            
              if (error(it,i) < tol)
                flag(i) = 1;
                prev(:,i) = new(:,i); 
              end
           end
               prev(:,i) = new(:,i);
          end
      end
     
     if (sum(flag) == M)
         error = error(1:it,:);
         error2 = error2(1:it,:);
         return;
     end
 end  
 
 
end
     