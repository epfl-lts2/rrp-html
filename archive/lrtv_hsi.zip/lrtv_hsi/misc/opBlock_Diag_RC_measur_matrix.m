function op = opBlock_Diag_RC_measur_matrix(x_size, nb_channel, nb_meas, s_gen, t_gen)

%
% OPDLOCK_DIAG_RC_MEASUR_MATRIX creates an operator of Distict Block Diagonal Random convolution measurement
% matrix
%
%   x_size:         input size
%   nb_channel:     number of channels
%   nb_meas:        number of measures
%
% Paper:
%           Compressive sensing 
% Author: Mahdad Hosseini Kamal, Mohammad Golbabaee; ,  Perraudin Nathana?l
% Contact: mahdad.hosseinikamal@epfl.ch, mohammad.golbabaei@epfl.ch,
% nathanael.perraudin@epfl.ch
% Date: June 2012
%
%   Url: https://epfl-lts2.github.io/rrp-html/lrtv_hsi/misc/opBlock_Diag_RC_measur_matrix.html

% Copyright (C) 2012-2013 Nathanael Perraudin.
% This file is part of RRP version 0.2
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.


 W_vector = repmat(s_gen,1,nb_channel);
 
 
 Theta = repmat( t_gen, 1, nb_channel);


op = @(x,mode) opRC_measur_matrix_internl(x_size, nb_channel, nb_meas, Theta, W_vector, x, mode);


end

function x = opRC_measur_matrix_internl(x_size, nb_channel, nb_meas, Theta, W_vector, x, mode)
    
if (mode == 1)
    
    
    x = reshape (x, x_size, nb_channel);

    x = OP_IFFT2_p(W_vector.* OP_FFT2_p(x));
    x = sqrt(nb_meas/x_size)*reshape(Theta.*x,x_size/nb_meas,nb_meas, nb_channel);
    x =  real(sum(x,1));
    x = x(:);
    

elseif (mode == 2)
    
    
    x = reshape(x, nb_meas, nb_channel);
    x_temp(1,:,:) = x;
    clear x;
    
    x_temp = (sqrt(nb_meas/x_size))*repmat(x_temp, x_size/nb_meas, 1);
    x_temp = reshape(x_temp, x_size, nb_channel);
    
    x_temp = real(OP_IFFT2_p(conj(W_vector).*(OP_FFT2_p(Theta.*x_temp))));
    x = x_temp(:);
  
  
elseif (mode == 0)
     x = {nb_meas,x_size,[0,1,0,1],{'RC_measur_matrix',nb_meas}};
     
else
    fprintf('There is no mode associated to the requested one')
end

end

