function op = opBlock_diag_same(J,op)
% Create a block Diagonal operator by the J times the repetition of the
% same operator op.
%
% This function is not optimal! 
%
% Autor: Nathana?l Perraudin 
% nathanael.perraudin@epfl.ch
%
%
%   Url: https://epfl-lts2.github.io/rrp-html/lrtv_hsi/misc/opBlock_diag_same.html

% Copyright (C) 2012-2013 Nathanael Perraudin.
% This file is part of RRP version 0.2
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.


info = op([],0);

m = info{1};            % Total number of rows
n = info{2};            % Total number of columns
 

op = @(x,mode) opBlockDiag_intrnl(m,n,op,x,mode,J);
end


function y = opBlockDiag_intrnl(m,n,op, x, mode,J)

    
   if mode==1 % Direct operator
   y  = zeros(m*J,1);
   kx = 0;
   ky = 0;
   for i=1:J

      
      
      y(ky+1:ky+m) = op(x(kx+1:kx+n),mode);
      kx              = kx + n;
      ky              = ky + m;
   end
   
   elseif mode==2 % inverse operator
   y  = zeros(n*J,1);
   kx = 0;
   ky = 0;
   for i=1:J

      
      
      y(ky+1:ky+n) = op(x(kx+1:kx+m),mode);
      kx              = kx + m;
      ky              = ky + n;
   end
   else
       error('Error here, unknow mode!\n 1 = operator, 2 = ajoint operator')
   end
   

end

