function [ F ] = OP_FFT2_p( f )
%OP_FFT2_p Compute the 2D fft of f row by row.
%   First: resize squarely the row, then compute the 2D FFT
%
%   Url: https://epfl-lts2.github.io/rrp-html/lrtv_hsi/misc/OP_FFT2_p.html

% Copyright (C) 2012-2013 Nathanael Perraudin.
% This file is part of RRP version 0.2
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.

[I,J]=size(f);

s_i=sqrt(I);
F=reshape(fft2(reshape(f,s_i,s_i,J)),I,J);


end


