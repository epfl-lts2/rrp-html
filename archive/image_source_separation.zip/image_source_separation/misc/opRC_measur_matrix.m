function op = opRC_measur_matrix(x_size,nb_meas)

%
% OPRC_MEASUR_MATRIX creates an operator of Random convolution measurement
% matrix
%
%   x_size:         input size
%   nb_meas:        number of measures
%
% Paper:
%           Compressive sensing 
% Author: Mahdad Hosseini Kamal
% Contact: mahdad.hosseinikamal@epfl.ch
% Date: Oct. 2010
%
%   Url: https://epfl-lts2.github.io/rrp-html/image_source_separation/misc/opRC_measur_matrix.html

% Copyright (C) 2012-2013 Nathanael Perraudin.
% This file is part of RRP version 0.2
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.


 W_vector = sigma_gen(x_size);
 Theta = theta (x_size);
 


op = @(x,mode) opRC_measur_matrix_internl(x_size, nb_meas, Theta, W_vector, x, mode);


end

function y = opRC_measur_matrix_internl(x_size, nb_meas, Theta, W_vector, x, mode)
    
if (mode == 1)


    H = ifft(W_vector.*fft(x));
    Bk = sqrt(nb_meas/x_size)*reshape(Theta.*H,x_size/nb_meas,nb_meas);
    y_temp =  real(sum(Bk,1));
    y = y_temp;
    y = y(:);
   
elseif (mode == 2)
    

    
    x_temp = (sqrt(nb_meas/x_size))*repmat(transpose(x(:)), x_size/nb_meas, 1);
    x_temp = x_temp(:);
    
    y_temp = real(ifft(conj(W_vector).*(fft(Theta.*x_temp))));
    y = y_temp;
    y = y(:);
  
  
elseif (mode == 0)
     y = {nb_meas,x_size,[0,1,0,1],{'RC_measur_matrix',nb_meas}};
     
else
    fprintf('There is no mode associated to the requested one')
end

end
    

