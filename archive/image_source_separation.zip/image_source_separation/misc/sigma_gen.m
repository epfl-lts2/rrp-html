function W_vector = sigma_gen(n)
%CREATE RANDOM PHASE SHIFT
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% M = sigma_gen(n)
%
%
% Genarate the Sigma matrix for Random Convolution
% n is the number of pixels inside the image
% M is a sparse diagonal matrix which its terms are random phase
%
%
%         --                        --
%         SIGMA_1 0 ...             
%         0      SIGMA_2 ...        
% SIGMA = .   .                     
%         .    .                    
%         .     .                   
%         0                SIGMA_N  
%         --                        --
%
%
% w = 1        --> sigma_1     +,-1 with equal prob
% 2<=w<n/2+1   --> sigma_w     exp(jtheta_w) theta_w Uniform([0,2pi])
% w = n/2+1    --> sigma_n/2+1 +,-1 with equal prob
% n/2+2<=w<=n  --> sigma_w     conjugate of sigma_n-w+2 
%
% because of huge amount of data we just store the diagonal
%
%
%            --       --
%            SIGMA_1  
% W_vector = SIGMA_2  
%             .       
%             .       
%             .       
%            SIGMA_N  
%            --       --
%
%
% Author: Mahdad Hosseini Kamal
% Contact: mahdad.hosseinikamal@epfl.ch
% Date: May 2010
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%   Url: https://epfl-lts2.github.io/rrp-html/image_source_separation/misc/sigma_gen.html

% Copyright (C) 2012-2013 Nathanael Perraudin.
% This file is part of RRP version 0.2
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.

W_vector = zeros(n,1);

if(rand>.5)
    W_vector(1,1) = 1;
else
    W_vector(1,1) = -1;
end

% for ii=n/2:-1:2
%     W_vector(ii,1) = exp(1j*2*pi*rand(1));
%     W_vector(n-ii+2,1) = conj(W_vector(ii));
% end

 W_vector(2:n/2,1)   = exp(1j*2*pi*rand(n/2-1,1));
 W_vector(n/2+2:n,1) = conj(W_vector(n/2:-1:2,1));

if(rand>.5)
    W_vector(n/2+1,1) = 1;
else
    W_vector(n/2+1,1) = -1;
end

%SIGMA = sparse(diag(W_vector));

end

