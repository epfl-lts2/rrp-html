%% Illustration of the localization operator
%
%   Url: https://epfl-lts2.github.io/rrp-html/stationarity/demo_localization.html

% Copyright (C) 2012-2013 Nathanael Perraudin.
% This file is part of RRP version 0.2
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.

clear
close all

gsp_reset_seed(0);
N = 100;
G = gsp_sensor(N);
G = gsp_compute_fourier_basis(G);

nodes = [1,34,83];

g = @(x) (10*x)/G.lmax.*exp(-(10*x).^2/G.lmax^2);



figure(1)
subplot(221)
gsp_plot_filter(G,g);
title('Filter, Mexican hat')

c = [-0.2 0.5];
subplot(222)
paramplot.vertex_highlight = nodes(1);
gsp_plot_signal(G,gsp_localize(G,g,nodes(1)),paramplot);
caxis(c);
subplot(223)
paramplot.vertex_highlight = nodes(2);
gsp_plot_signal(G,gsp_localize(G,g,nodes(2)),paramplot);
caxis(c);

subplot(224)
paramplot.vertex_highlight = nodes(3);
gsp_plot_signal(G,gsp_localize(G,g,nodes(3)),paramplot);
caxis(c);

gsp_plotfig('demo_localization')
