function [sol, infos] = gsp_tik_deconvolution_noise(G, x0, h, sigma, param)

if nargin<5
    param = struct;
end

if ~isfield(param,'verbose'), param.verbose = 1; end


% Fidelity term for Tikonov an TV
%
%   Url: https://epfl-lts2.github.io/rrp-html/stationarity/gsp_tik_deconvolution_noise.html

% Copyright (C) 2012-2013 Nathanael Perraudin.
% This file is part of RRP version 0.2
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.
paramproj.epsilon = sqrt(G.N)*sigma;
paramproj.verbose = param.verbose - 1;
paramproj.tight = 0;
ffid.prox = @(x,T) gsp_proj_b2_filterbank(x, T, G, h, x0, paramproj);
ffid.eval = @(x) eps;

% TV regularizer
ftik.grad = @(x) 2*G.L*x;
ftik.eval = @(x) gsp_norm_tik(G,x);
ftik.beta = 2*G.lmax;

% Solve the problem
[sol, infos] = solvep(x0,{ffid,ftik}, param);


end
