function sol = grm_estimator(C, M, s, sigma)

if nargin<4
    sigma = 0;
end

if size(M,1)<numel(M)
    error('M should be a column vector')
end

Cnn = C(logical(M),logical(M));
%Cuu = C(~logical(M),~logical(M));
%
%   Url: https://epfl-lts2.github.io/rrp-html/stationarity/grm_estimator.html

% Copyright (C) 2012-2013 Nathanael Perraudin.
% This file is part of RRP version 0.2
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.
Cun = C(~logical(M),logical(M));
sol = zeros(size(s));
sol(logical(M),:) = Cnn * (( Cnn + sigma*eye(sum(double(M))) ) \ s(logical(M),:));
sol(~logical(M),:) = (Cun * (( Cnn + sigma*eye(sum(double(M))) ) \ s(logical(M),:)));

end
