function [  ] = plotfft( ffts,fs )
%PLOTFFT Plot the fft in a nice way
%   Usage: plotfft( ffts );
%
%   Input arguments:
%       ffts    : fft of the signal s
%       fs      : sampling frequency
%   Ouput arguments:
%       none
%  
%
%   Url: https://epfl-lts2.github.io/rrp-html/srfsp/plotfft.html

% Copyright (C) 2012-2013 Nathanael Perraudin.
% This file is part of RRP version 0.2
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.

% Author: Nathanael Perraudin
% Date: 12 Mai 2014

N = length(ffts);

w = linspace(0,fs-fs/N,N);

plot(w,abs(ffts(:)));
xlabel('Frequency')
ylabel('Modulus')
xlim([0,fs/2]);
drawnow;

end


