function [ s ] = plot_signal_fftreal( x,p,fig,fs,sol )
%PLOT_SIGNAL_FFTREAL Plot image plugin for the UNLocBoX
%   Usage [ s ] = plot_signal_fftreal( im,fig );
%
%   Input parameters:
%         x     : Structure of data
%         p     : Number of iteration between 2 plots...
%         fig   : Figure
%         fs    : Sampling frequency
%
%   Output parameters:
%         s     : Input image
%
%   This plugin display the signal every iterations of an algorithm. To use
%   the plugin juste define:
%       
%       fig=figure(100);
%       param.do_sol=@(x) plot_signal_fftreal(x,p,fig);
%
%   In the structure of optional argument of the solver.
%
%
%   Url: https://epfl-lts2.github.io/rrp-html/srfsp/plot_signal_fftreal.html

% Copyright (C) 2012-2013 Nathanael Perraudin.
% This file is part of RRP version 0.2
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.

% Author: Nathanael Perraudin
% Date  : 3rd april 2014

if ~mod(x.iter-1,p)
    % select the figure
    if x.iter<2
        figure(fig);
    end
    % display the signal
    N = length(x.sol);

    w = linspace(0,fs-fs/N,N);
    subplot(121)
    plot(w,abs(x.sol(:)));
    xlabel('Frequency')
    ylabel('Modulus')
    title(['Current it: ', num2str(x.iter),'   Curr obj: ', ...
        num2str(x.curr_norm)]);
    subplot(122)
    plot(w,abs(sol(:)));
    xlabel('Frequency')
    ylabel('Modulus')
    title(['Solution,  diff = ',num2str(norm(x.sol(:)-sol(:)))]);
    drawnow;
end


s=x.sol;



end

