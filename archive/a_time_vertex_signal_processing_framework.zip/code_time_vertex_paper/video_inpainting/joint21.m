
clear param_fid f1 f2 f3
tau1 = 5;
tau2 = 0.1;
verbose = 1;


% fig = figure(100);

param_fid.A         = @(x) M.*x;
param_fid.At        = @(x) M.*x;
param_fid.tight     = 1;

%time tv
f2.prox = @(x,T) prox_tv1d(x',T*tau1)'; % X'*LT
f2.eval = @(x) tau1*norm(vec(x*G.jtv.DiffT'),1);

%graph tik
f3.grad = @(x,T) tau2*2*G.L*x;
f3.beta = 2*G.lmax*tau2;
f3.eval = @(x) tau2*norm(G.Diff*x,'fro').^2;

%RED
% param_solver.do_sol=@(x) plot_videoframe( x,[height width 1 T],[1 3 10 50],fig,xr );
param_fid.y = yr;
f1.grad = @(x) 2*M.*(x-param_fid.y);
f1.eval = @(x) norm(M.*(x-param_fid.y),'fro').^2;
f1.beta = 2;
zr = solvep(yr,{f1 f2 f3},param_solver);
compute_error(zr,xr)

%GREEN
% param_solver.do_sol=@(x) plot_videoframe( x,[height width 1 T],[1 3 10 50],fig,xg );
param_fid.y = yg;
f1.grad = @(x) 2*M.*(x-param_fid.y);
f1.eval = @(x) norm(M.*(x-param_fid.y),'fro').^2;
zg = solvep(yg,{f1 f2 f3},param_solver);
compute_error(zg,xg)

%BLUE
% param_solver.do_sol=@(x) plot_videoframe( x,[height width 1 T],[1 3 10 50],fig,xb );
param_fid.y = yb;
f1.grad = @(x) 2*M.*(x-param_fid.y);
f1.eval = @(x) norm(M.*(x-param_fid.y),'fro').^2;
zb = solvep(yb,{f1 f2 f3},param_solver);
compute_error(zb,xb)


z21(:,1,:) = zr;
z21(:,2,:) = zg;
z21(:,3,:) = zb;


Zr = reshape(zr,height,width,T);
Zg = reshape(zg,height,width,T);
Zb = reshape(zb,height,width,T);
Z21(:,:,1,:) = Zr;
Z21(:,:,2,:) = Zg;
Z21(:,:,3,:) = Zb;
