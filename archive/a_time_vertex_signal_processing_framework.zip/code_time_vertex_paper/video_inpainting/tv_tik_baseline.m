
Nt = T;
ffid.eval = @(x) eps;

ftik.grad = @(x) -2*laplacian_op3(x);
ftik.eval = @(x) -(sum(vec(x.*laplacianx_op(x))) + sum(vec(x.*laplaciany_op(x))) + sum(vec(x.*laplacianz_op(x))));
ftik.beta = 20;


ts = 1;
ftv.prox = @(x,T) prox_tv3d(x,ts*T,param_tv);
ftv.eval = @(x) norm_tv3d(x);

% paramsolver.tol = 1e-5;


ffid.prox = @(x,T) reshape(yr,height,width,Nt) + (x-reshape(M,height,width,Nt).*(x));
tikr = solvep(reshape(yr,height,width,Nt),{ffid,ftik},param_solver);
tvr  = solvep(reshape(yr,height,width,Nt),{ffid,ftv},param_solver);

ffid.prox = @(x,T) reshape(yg,height,width,Nt) + (x-reshape(M,height,width,Nt).*(x));
tikg = solvep(reshape(yg,height,width,Nt),{ffid,ftik},param_solver);
tvg  = solvep(reshape(yg,height,width,Nt),{ffid,ftv},param_solver);

ffid.prox = @(x,T) reshape(yb,height,width,Nt) + (x-reshape(M,height,width,Nt).*(x));
tikb = solvep(reshape(yb,height,width,Nt),{ffid,ftik},param_solver);
tvb  = solvep(reshape(yb,height,width,Nt),{ffid,ftv},param_solver);

tik = permute(cat(4,tikr,tikg,tikb),[1 2 4 3]);
tv  = permute(cat(4,tvr,tvg,tvb),[1 2 4 3]);
